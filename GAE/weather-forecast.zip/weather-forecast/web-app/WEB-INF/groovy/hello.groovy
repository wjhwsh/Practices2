html.html {
	head {
		title "Hello"
	}
	body {
		p "Hello Groovy World!"
	}
}